<?php   
  $servername = "127.0.0.1";
  $username = "root";
  $password = "";
  $dbname = "feedie_base";
  $conn = new mysqli($servername, $username, $password, $dbname);
?>