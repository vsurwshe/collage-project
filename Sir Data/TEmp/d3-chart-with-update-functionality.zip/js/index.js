var chartWidth,chartHeight,chartHeight2;
var x,y,xAxis,x2Axis,yAxis,y2Axis,xAxisObj, yAxisObj;
var d3_width, d3_height,d3_maxBarWidth;
var svg,focus;
var isAnimated = true;
var chartType = "bar";
var chartSizes = {
  "height": 400,
  "width": 700,
};

function init(){
  drawChart( _.take(chartData,25), chartSizes);  
}

function drawChart(series,chartSizes){

    d3_width = chartSizes.width;
    d3_height = chartSizes.height;
    d3_maxBarWidth = d3_width / 15;
    chartWidth = d3_width;
    chartHeight = d3_height;

    createAxis(series);
    svg = createSVGElement();
    focus = appendG(svg, "focus");
    appendAxis(focus);
    
    var line = createLine(x, y);
    appendLine(focus, series, line,isAnimated);
    //appendBars(focus, series);
}

function updateChart( data ){

    var chartData = _.map(data, function (d, i) {
                            return { name: d.id, value: d.amount };
                        });

    x.domain(chartData.map(function (d) { return d.name; }));
    y.domain([0, d3.max(chartData, function(d) { return d.value; })]);

    var svg = d3.select(".chart_1 svg").transition();

    appendBars(focus, chartData);
    
    svg.select(".x.d3-axis") // change the x axis
        .duration(750)
        .call(xAxis);
    svg.select(".y.d3-axis") // change the y axis
        .duration(750)
        .call(yAxis);
}

function appendBars(_element, _data) {
    _element.selectAll("rect").remove();
    var bars = _element.selectAll(".d3-bar");

    bars.data(_data)
        .enter()
        .append("rect")
        .attr("class", "d3-bar")
        .on("click",function(data, index){
            updateChart( _.takeRight(waveData, Math.floor((Math.random() * 20) + 5)  ) );
        })
        .attr("x", function (d) {
            if (x.rangeBand() > d3_maxBarWidth) {
                return x(d.name) + x.rangeBand() / 2 - d3_maxBarWidth / 2;
            } else {
                return x(d.name);
            }
        })
        .attr("width", (x.rangeBand() > d3_maxBarWidth ? d3_maxBarWidth : x.rangeBand()))
        .attr("y", chartHeight)
        .attr("height", 0)
        .transition()
        .duration(1000)
        .ease("bounce")
        .attr("y", function (d) { return y(d.value); })
        .attr("height", function (d) { return chartHeight - y(d.value); });
};

function appendLine(_element, _data, _line, _animated) {
    if (_animated) {
        var path = _element.append("path")
        .datum(_data)
        .attr({
            class: "d3-line",
            d:  _line,
            stroke: "steelblue",
            "stroke-width": "2",
            fill: "none"
        });
        if (path.node() == null || path.node().getAttribute("d") == null)
            return;
        var totalLength = path.node().getTotalLength();

        path
            .attr({
                "stroke-dasharray": totalLength + " " + totalLength,
                "stroke-dashoffset": totalLength
            })
            .transition()
            .duration(1500)
            .ease("linear")
            .attr("stroke-dashoffset", 0);

    } else {
        _element.append("path")
            .datum(_data)
            .attr({
                class: "d3-line",
                d: _line
            });
    }

}

function createLine(_x, _y, isSecondLine) {
    return (d3.svg.line()
            .interpolate("monotone")
            .x(function (d) { return _x(d.name); })
            .y(function (d) { return _y(d.value); }));
}

function appendAxis(_element) {
    xAxisObj = _element.append("g")
        .attr({
            class: "x d3-axis",
            transform: "translate(0," + chartHeight + ")"
        })
        .call(xAxis);

    yAxisObj = _element.append("g")
        .attr({
            class: "y d3-axis"
        })
        .call(yAxis);
}

function appendG(_svg, _element) {
    return (_svg.append("g")
            .attr({
                class: _element,
                transform: "translate(0,0)"
            })
           );
}

function createSVGElement() {
    return (d3.select(".chart_1").append("svg")
            .attr({
                width: chartWidth,
                height: chartHeight
            })
            .style({
                overflow: "visible",
                padding: "100px"
            })
           );
}

function createAxis(series){
    x = scaleOrdinal(series);
    y = scaleLinear(series, chartHeight);
  
    xAxis = d3.svg.axis().scale(x).orient("bottom");
    yAxis = d3.svg.axis().scale(y).orient("left");
}

function scaleOrdinal(series) {

    var axisDomain = d3.scale.ordinal()
        .domain(_.map(series,function (d) { return d.name; }));
    if (chartType == "bar") {
        axisDomain.rangeRoundBands([0, chartWidth], .1);
    } else {
        axisDomain.rangePoints([0, chartWidth]);
    }
    return axisDomain;
}

function scaleLinear(series) {
    var maxElement = d3.max(series, function (d) { return parseFloat(d.value); }) * 1.25;
    return (d3.scale.linear()
            .domain([0, maxElement])
            .range([chartHeight, 0]));
}

var chartData = [
  {
    "value": 83,
    "name": "Josefina Perkins"
  },
  {
    "value": 134,
    "name": "Sheppard Lee"
  },
  {
    "value": 84,
    "name": "Franklin Velez"
  },
  {
    "value": 64,
    "name": "Andrea Hood"
  },
  {
    "value": 65,
    "name": "Karla Bolton"
  },
  {
    "value": 116,
    "name": "Barr Chapman"
  },
  {
    "value": 147,
    "name": "Coleman Welch"
  },
  {
    "value": 49,
    "name": "Williams Bray"
  },
  {
    "value": 162,
    "name": "Duran Navarro"
  },
  {
    "value": 60,
    "name": "Melanie Cline"
  },
  {
    "value": 127,
    "name": "Santos Frazier"
  },
  {
    "value": 200,
    "name": "Sarah Gilliam"
  },
  {
    "value": 113,
    "name": "Ortega Holt"
  },
  {
    "value": 111,
    "name": "Marguerite Gay"
  },
  {
    "value": 127,
    "name": "Ginger Prince"
  },
  {
    "value": 103,
    "name": "Holmes Lane"
  },
  {
    "value": 196,
    "name": "Mathews Short"
  },
  {
    "value": 26,
    "name": "Jenna Swanson"
  },
  {
    "value": 77,
    "name": "Williamson Mcdonald"
  },
  {
    "value": 112,
    "name": "Charlotte Vaughan"
  },
  {
    "value": 47,
    "name": "Ladonna Glenn"
  },
  {
    "value": 58,
    "name": "Irma Potts"
  },
  {
    "value": 89,
    "name": "Berg Maxwell"
  },
  {
    "value": 37,
    "name": "Dianne Lewis"
  },
  {
    "value": 67,
    "name": "Odom Snyder"
  },
  {
    "value": 94,
    "name": "Gibson Ruiz"
  },
  {
    "value": 187,
    "name": "Melva Everett"
  },
  {
    "value": 32,
    "name": "Fischer Kramer"
  },
  {
    "value": 85,
    "name": "Rae Joyce"
  },
  {
    "value": 52,
    "name": "Georgina Black"
  },
  {
    "value": 121,
    "name": "Rena Ferrell"
  },
  {
    "value": 105,
    "name": "Sawyer Hays"
  },
  {
    "value": 104,
    "name": "Fitzpatrick Coleman"
  },
  {
    "value": 50,
    "name": "Mcmillan Bond"
  },
  {
    "value": 139,
    "name": "Pickett Bender"
  },
  {
    "value": 62,
    "name": "Le Hughes"
  },
  {
    "value": 38,
    "name": "Kim Jefferson"
  },
  {
    "value": 46,
    "name": "Maynard Sparks"
  },
  {
    "value": 167,
    "name": "Hurst Leblanc"
  },
  {
    "value": 144,
    "name": "Barrett Coffey"
  },
  {
    "value": 38,
    "name": "Kidd Sanders"
  },
  {
    "value": 41,
    "name": "Oconnor Dickson"
  },
  {
    "value": 109,
    "name": "Bolton Nicholson"
  },
  {
    "value": 167,
    "name": "Roslyn Green"
  },
  {
    "value": 117,
    "name": "Palmer Mclean"
  },
  {
    "value": 61,
    "name": "Burris Vance"
  },
  {
    "value": 166,
    "name": "Tessa Watson"
  },
  {
    "value": 165,
    "name": "Estela Mendoza"
  },
  {
    "value": 199,
    "name": "Jocelyn Palmer"
  },
  {
    "value": 40,
    "name": "Leslie Guzman"
  },
  {
    "value": 101,
    "name": "Simon Wolf"
  },
  {
    "value": 44,
    "name": "Pearl Patterson"
  },
  {
    "value": 104,
    "name": "Knight Pena"
  },
  {
    "value": 79,
    "name": "Sue Hickman"
  },
  {
    "value": 33,
    "name": "Kelly Tillman"
  },
  {
    "value": 70,
    "name": "Audrey Patrick"
  },
  {
    "value": 78,
    "name": "Vang Lancaster"
  },
  {
    "value": 81,
    "name": "Charles Hawkins"
  },
  {
    "value": 117,
    "name": "Good Mcfadden"
  },
  {
    "value": 173,
    "name": "Burch Garza"
  },
  {
    "value": 86,
    "name": "Bush Morgan"
  },
  {
    "value": 25,
    "name": "Russo Goodwin"
  },
  {
    "value": 54,
    "name": "Johnson Huber"
  },
  {
    "value": 36,
    "name": "Lillian Richard"
  },
  {
    "value": 103,
    "name": "Valencia Boyd"
  },
  {
    "value": 138,
    "name": "Cain Raymond"
  },
  {
    "value": 180,
    "name": "Anne Blanchard"
  },
  {
    "value": 100,
    "name": "Elsa Campos"
  },
  {
    "value": 174,
    "name": "Fay Carson"
  },
  {
    "value": 46,
    "name": "Wendy Burke"
  },
  {
    "value": 132,
    "name": "Nell Robertson"
  },
  {
    "value": 172,
    "name": "Earnestine Carver"
  },
  {
    "value": 23,
    "name": "Marta Meyer"
  },
  {
    "value": 69,
    "name": "Mathis Clay"
  },
  {
    "value": 40,
    "name": "Mavis Logan"
  },
  {
    "value": 165,
    "name": "Burgess Rowe"
  },
  {
    "value": 157,
    "name": "Hopkins Savage"
  },
  {
    "value": 85,
    "name": "Joanne Decker"
  },
  {
    "value": 99,
    "name": "Young Luna"
  },
  {
    "value": 55,
    "name": "Davidson Gilbert"
  },
  {
    "value": 93,
    "name": "Salazar Crosby"
  },
  {
    "value": 136,
    "name": "Marshall Klein"
  },
  {
    "value": 78,
    "name": "Rosa Gibson"
  },
  {
    "value": 151,
    "name": "Lou Perry"
  },
  {
    "value": 116,
    "name": "Brewer Garrett"
  },
  {
    "value": 25,
    "name": "Wooten Jacobson"
  },
  {
    "value": 45,
    "name": "Frank Vincent"
  },
  {
    "value": 45,
    "name": "Tyson Park"
  },
  {
    "value": 95,
    "name": "Dixie Roach"
  },
  {
    "value": 132,
    "name": "Soto Moss"
  },
  {
    "value": 63,
    "name": "Lora Singleton"
  },
  {
    "value": 120,
    "name": "Bethany Carr"
  },
  {
    "value": 105,
    "name": "Lourdes Spencer"
  },
  {
    "value": 112,
    "name": "Bobbie Garcia"
  },
  {
    "value": 93,
    "name": "Diann Hayden"
  },
  {
    "value": 194,
    "name": "Arline Torres"
  },
  {
    "value": 137,
    "name": "Mcdaniel Harmon"
  },
  {
    "value": 78,
    "name": "Randall Gillespie"
  },
  {
    "value": 59,
    "name": "Hall Clemons"
  },
  {
    "value": 190,
    "name": "Heather Cannon"
  },
  {
    "value": 56,
    "name": "Matthews French"
  },
  {
    "value": 42,
    "name": "Berry Myers"
  },
  {
    "value": 168,
    "name": "Blevins Madden"
  },
  {
    "value": 48,
    "name": "Donna Cooley"
  },
  {
    "value": 23,
    "name": "Cecile Evans"
  },
  {
    "value": 97,
    "name": "Harriett Sherman"
  },
  {
    "value": 38,
    "name": "Gardner Levy"
  },
  {
    "value": 161,
    "name": "Mckay Howell"
  },
  {
    "value": 150,
    "name": "Calderon Lindsay"
  },
  {
    "value": 99,
    "name": "Kim Bates"
  },
  {
    "value": 113,
    "name": "Beach Hobbs"
  },
  {
    "value": 91,
    "name": "Jerri Witt"
  },
  {
    "value": 186,
    "name": "Debbie Allen"
  },
  {
    "value": 64,
    "name": "Ilene Leon"
  },
  {
    "value": 147,
    "name": "Alice Combs"
  },
  {
    "value": 55,
    "name": "Alston Simon"
  },
  {
    "value": 46,
    "name": "Giles Jensen"
  },
  {
    "value": 47,
    "name": "Gloria Cote"
  },
  {
    "value": 133,
    "name": "Noelle Harvey"
  },
  {
    "value": 122,
    "name": "Cara Martin"
  },
  {
    "value": 73,
    "name": "Cecilia Holmes"
  },
  {
    "value": 58,
    "name": "Nadia Mccall"
  },
  {
    "value": 172,
    "name": "Wyatt Hart"
  },
  {
    "value": 176,
    "name": "Pace Hodge"
  },
  {
    "value": 196,
    "name": "Nina Dodson"
  },
  {
    "value": 180,
    "name": "Maggie Arnold"
  },
  {
    "value": 75,
    "name": "Salinas Hall"
  },
  {
    "value": 200,
    "name": "Elvira Brock"
  },
  {
    "value": 146,
    "name": "Graves Gomez"
  },
  {
    "value": 174,
    "name": "Deena Marshall"
  },
  {
    "value": 123,
    "name": "Ellison Howard"
  },
  {
    "value": 71,
    "name": "Casandra Briggs"
  },
  {
    "value": 69,
    "name": "Marina Watts"
  },
  {
    "value": 83,
    "name": "Larson Anthony"
  },
  {
    "value": 197,
    "name": "Etta Castillo"
  },
  {
    "value": 167,
    "name": "Estrada Sims"
  },
  {
    "value": 25,
    "name": "Rosemary Rose"
  },
  {
    "value": 179,
    "name": "Brandi Rivers"
  },
  {
    "value": 133,
    "name": "Perkins Henderson"
  },
  {
    "value": 53,
    "name": "Helene Rollins"
  },
  {
    "value": 81,
    "name": "Chase Gould"
  },
  {
    "value": 139,
    "name": "Christy Stafford"
  },
  {
    "value": 55,
    "name": "Bray Cortez"
  },
  {
    "value": 44,
    "name": "Brock Solomon"
  },
  {
    "value": 99,
    "name": "Paula Cook"
  },
  {
    "value": 91,
    "name": "Theresa Buckley"
  },
  {
    "value": 121,
    "name": "Marjorie Hendrix"
  },
  {
    "value": 55,
    "name": "Donaldson Mcguire"
  },
  {
    "value": 76,
    "name": "Fleming Nieves"
  },
  {
    "value": 194,
    "name": "Allyson Santos"
  },
  {
    "value": 135,
    "name": "Bowers Copeland"
  },
  {
    "value": 106,
    "name": "Jennifer Avila"
  },
  {
    "value": 118,
    "name": "Stevenson Knox"
  },
  {
    "value": 66,
    "name": "Wheeler Whitley"
  },
  {
    "value": 57,
    "name": "Roy Barron"
  },
  {
    "value": 185,
    "name": "Humphrey Cash"
  },
  {
    "value": 197,
    "name": "Jana Ewing"
  },
  {
    "value": 67,
    "name": "Callahan Doyle"
  },
  {
    "value": 198,
    "name": "Ward Paul"
  },
  {
    "value": 183,
    "name": "Christie Olson"
  },
  {
    "value": 42,
    "name": "Walters Callahan"
  },
  {
    "value": 60,
    "name": "Trevino Guy"
  },
  {
    "value": 135,
    "name": "Nichole Hernandez"
  },
  {
    "value": 165,
    "name": "Kemp Burris"
  },
  {
    "value": 184,
    "name": "Marlene Hartman"
  },
  {
    "value": 103,
    "name": "Ursula Harris"
  },
  {
    "value": 200,
    "name": "Lauri Potter"
  },
  {
    "value": 166,
    "name": "Rasmussen Lamb"
  },
  {
    "value": 38,
    "name": "Crystal Whitehead"
  },
  {
    "value": 186,
    "name": "Fannie Bradford"
  },
  {
    "value": 137,
    "name": "Clemons Houston"
  },
  {
    "value": 178,
    "name": "Briana Collins"
  },
  {
    "value": 102,
    "name": "Natalia Miranda"
  },
  {
    "value": 179,
    "name": "Flossie Meadows"
  },
  {
    "value": 130,
    "name": "Victoria Lopez"
  },
  {
    "value": 188,
    "name": "Carter Weber"
  },
  {
    "value": 161,
    "name": "Chelsea Bullock"
  },
  {
    "value": 44,
    "name": "Wong Osborn"
  }
];

init();