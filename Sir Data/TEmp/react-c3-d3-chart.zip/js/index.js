var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _React = React,
    Component = _React.Component;

var columns = [['My Numbers', 30, 200, 100, 400, 150, 250], ['Your Numbers', 50, 20, 10, 40, 15, 25]];

var Chart = function (_Component) {
  _inherits(Chart, _Component);

  function Chart() {
    _classCallCheck(this, Chart);

    return _possibleConstructorReturn(this, (Chart.__proto__ || Object.getPrototypeOf(Chart)).apply(this, arguments));
  }

  _createClass(Chart, [{
    key: 'componentDidMount',
    value: function componentDidMount() {
      this._updateChart();
    }
  }, {
    key: 'componentDidUpdate',
    value: function componentDidUpdate() {
      this._updateChart();
    }
  }, {
    key: '_updateChart',
    value: function _updateChart() {
      var chart = c3.generate({
        bindto: '#chart',
        data: {
          columns: this.props.columns,
          type: this.props.chartType
        }
      });
    }
  }, {
    key: 'render',
    value: function render() {
      return React.createElement(
        'div',
        { id: 'chart' },
        'hi'
      );
    }
  }]);

  return Chart;
}(Component);

var App = function (_Component2) {
  _inherits(App, _Component2);

  function App(props) {
    _classCallCheck(this, App);

    var _this2 = _possibleConstructorReturn(this, (App.__proto__ || Object.getPrototypeOf(App)).call(this, props));

    _this2._setBarChart = _this2._setBarChart.bind(_this2);
    _this2._setLineChart = _this2._setLineChart.bind(_this2);
    _this2.state = {
      chartType: 'line'
    };
    return _this2;
  }

  _createClass(App, [{
    key: '_setBarChart',
    value: function _setBarChart() {
      this.setState({ chartType: 'bar' });
    }
  }, {
    key: '_setLineChart',
    value: function _setLineChart() {
      this.setState({ chartType: 'line' });
    }
  }, {
    key: 'render',
    value: function render() {
      return React.createElement(
        'div',
        { className: 'app-wrap' },
        React.createElement(Chart, {
          columns: columns,
          chartType: this.state.chartType }),
        React.createElement(
          'p',
          null,
          'Chart Type',
          React.createElement(
            'button',
            { onClick: this._setBarChart },
            'bar'
          ),
          React.createElement(
            'button',
            { onClick: this._setLineChart },
            'Line'
          )
        )
      );
    }
  }]);

  return App;
}(Component);

ReactDOM.render(React.createElement(App, null), document.getElementById('app'));