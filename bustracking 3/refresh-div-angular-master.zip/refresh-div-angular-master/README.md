refresh-div-angular
===================

Refresh DIV in 10 Seconds using $interval

$interval angular service demonstration. 

web-site: http://codeforgeek.com
